**Arabic Cnverter text**
install in cmd write 
```pip install Arabic```
```import Arabic```
```a=arabic()```
```a=a.Arabic("Write your arabic text here")```
```print(a)```  
**A quick way to use it**
```import Arabic```
```
arabic().print("السلام عليكم")
```

or 
``` 
print(arabic().arabic("السلام عليكم"))
```